﻿
#include"TCP.h"
#include"DES.h"
#include<WinSock2.h>
#pragma comment(lib,"ws2_32.lib")

SOCKET sock_ser, sock_cli;
SOCKADDR_IN addr_ser, addr_cli;
int len = sizeof(SOCKADDR_IN);

int ID;

char send_buf[BUF_SIZE] = {};
char recv_buf[BUF_SIZE] = {};

DWORD WINAPI send_thread(LPVOID lparam);
DWORD WINAPI recv_thread(LPVOID lparam);

HANDLE hThread1, hThread2;
DWORD dwThreadId1, dwThreadId2;

int cond;

u_char key_final[16][6];
u_char key_final_[16][6];


int main()
{
    cout << "CLIENT" << endl << endl;

    WSADATA wsadata;
    if (WSAStartup(MAKEWORD(2, 2), &wsadata) != 0)
    {
        cout << "SOCKET INIT ERROR!" << endl;
        return 0;
    }

    struct timeval timeout;
    timeout.tv_sec = 1;
    timeout.tv_usec = 0;

    SOCKET sock_client = socket(AF_INET, SOCK_STREAM, 0);
    if (setsockopt(sock_client, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(timeout)) == -1)
    {
        cout<<"setsockopt failed: ";
    }

    addr_cli.sin_addr.s_addr = inet_addr("127.0.0.1");
    addr_cli.sin_family = AF_INET;
    int port;
    cout << "Please input client port: ";
    cin >> port;
    addr_cli.sin_port = htons(port);

    addr_ser.sin_addr.s_addr = inet_addr("127.0.0.1");
    addr_ser.sin_family = AF_INET;
    addr_ser.sin_port = htons(PORT);

    cout << "Connecting..." << endl;
    sock_cli = connect(sock_client, (SOCKADDR*)&addr_ser, sizeof(SOCKADDR));

    if (sock_cli != SOCKET_ERROR)
    {
        cout << "Connect sucess." << endl;
        while (1)
        {
            recv(sock_client, recv_buf, 50, 0);
            cout << recv_buf << endl;
            ID = recv_buf[20] - 48;
            //cout << "ID = " << ID << endl;

            memset(recv_buf, 0, sizeof(recv_buf));
            recv(sock_client, recv_buf, 50, 0);

            cout << "DES_KEY = ";
            //生成密钥
            Get_Keys((u_char*)recv_buf, key_final);

            for (int i = 0; i < 16; i++)
                for (int j = 0; j < 6; j++)
                    key_final_[15 - i][j] = key_final[i][j];

            for (int i = 0; i < 8; i++)
                printf("%02X", recv_buf[i]);
            cout << endl;

            break;
            Sleep(30);
        }
    }
    while (1)
    {
        hThread1 = ::CreateThread(NULL, NULL, send_thread, LPVOID(sock_client), 0, &dwThreadId1);
        hThread2 = ::CreateThread(NULL, NULL, recv_thread, LPVOID(sock_client), 0, &dwThreadId2);
        WaitForSingleObject(hThread1, 200);
        WaitForSingleObject(hThread2, 200);
        if (cond)
            break;
    }
    closesocket(sock_client);
    WSACleanup();
    return 0;
}


DWORD WINAPI send_thread(LPVOID lparam)
{
    while (1)
    {
        char send_buf[BUF_SIZE] = {};
        char buffer[BUF_SIZE] = {};
        SOCKET sock_client = (SOCKET)(LPVOID)lparam;

        cin.getline(buffer, 2048, '\n');
        if (buffer[0])
        {
            send_buf[0] = ID + 48;

            if (!strcmp(buffer, "quit"))
            {
                send_buf[1] = ID + 48;
                strcat_s(send_buf, buffer);
                send(sock_client, send_buf, 2048, 0);
                cond = 1;
                return 0;
            }

            send_buf[1] = buffer[0];
            int i = 1;
            for (; buffer[i]; i++)
            {
                buffer[i - 1] = buffer[i];
            }
            buffer[i - 1] = 0;

            char buf[BUF_SIZE] = {};
            msg_en(buffer, key_final, buf);

            strcat(send_buf, buf);
            send(sock_client, send_buf, 2048, 0);
        }
        Sleep(200);
    }
    return 0;
}
DWORD WINAPI recv_thread(LPVOID lparam)
{
    while (1)
    {
        char recv_buf[BUF_SIZE] = {};
        SOCKET sock_client = (SOCKET)(LPVOID)lparam;
        recv(sock_client, recv_buf, 2048, 0);

        if (recv_buf[0])
        {

            cout << recv_buf[0] << ": ";

            int i = 2;
            for (; recv_buf[i] != 0; i++)
                recv_buf[i - 2] = recv_buf[i];
            recv_buf[i - 2] = 0;
            recv_buf[i - 1] = 0;

            char buf[BUF_SIZE] = {};
            msg_de(recv_buf, key_final_, buf);
            
            cout << buf << endl;

        }
        Sleep(200);
    }
    return 0;
}