#pragma once
# define _CRT_SECURE_NO_WARNINGS
# define _WINSOCK_DEPRECATED_NO_WARNINGS

#include"DES.h"
#include<string.h>

#define BUF_SIZE 2048
#define PORT 6666
#define CLIENT_NUM 2

class msg_form
{
public:
	char send_id;
	char recv_id;
	char msg[BUF_SIZE];
	msg_form() { memset(msg, 0, BUF_SIZE); }
	msg_form(const char a, const char b, const char c[BUF_SIZE])
	{
		send_id = a;
		recv_id = b;
		strcpy_s(msg, c);
	}
	msg_form(char a, char b, char c[BUF_SIZE])
	{
		send_id = a;
		recv_id = b;
		strcpy_s(msg, c);
	}
};

msg_form str2msg(char a[])
{
	msg_form msg_;
	msg_.send_id = a[0];
	msg_.recv_id = a[1];
	for (int i = 0; a[i + 2]; i++)
	{
		msg_.msg[i] = a[i + 2];
	}
	return msg_;
}

char* msg_en(char* a, u_char key_final[16][6], char* cipher)
{
	int len = strlen(a);
	u_char temp[8], temp_cipher[8];
	int index = 0;
	memset(cipher, 0, BUF_SIZE);
	for (int i = 0; i < len; i+=8)
	{
		memset(temp, 0, sizeof(temp));
		memset(temp_cipher, 0, sizeof(temp_cipher));
		for (int j = 0; j < 8; j++)
		{
			temp[j] = (u_char)a[i + j];
		}
		Round(temp, key_final, temp_cipher);
		for (int j = 0; j < 8; j++)
		{
			cipher[index++] = temp_cipher[j];
		}
	}
	return cipher;
}

char* msg_de(char* a, u_char key_final[16][6], char* m)
{
	int len = strlen(a);
	u_char temp[8], tempm[8];
	int index = 0;
	memset(m, 0, BUF_SIZE);
	for (int i = 0; i < BUF_SIZE; i += 8)
	{
		memset(temp, 0, sizeof(temp));
		memset(tempm, 0, sizeof(tempm));
		for (int j = 0; j < 8; j++)
		{
			temp[j] = a[i + j];
		}
		Round(temp, key_final, tempm);
		for (int j = 0; j < 8; j++)
		{
			m[index++] = tempm[j];
		}
	}
	return m;
}
