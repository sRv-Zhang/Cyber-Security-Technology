#include"DES.h"

using namespace std;
int u_char2bit(tuple_ a)//���ֽ�������Ϊ������
{
	return a.u_char_ * 8 + a.bit_;
}

tuple_ bit2u_char(int a)//����������Ϊ�ֽ�����
{
	tuple_ b;
	b.u_char_ = a / 8;
	b.bit_ = a % 8;
	return b;
}

int get_bit(u_char a, int x)//ȡ�ڼ�λ
{
	a = a << x;
	a = a >> 7;
	return a;
}

void write(u_char& a, int x, int num)//��numд��a�ĵ�xλ
{
	a += num << (7 - x);
}

void convert(u_char a[], u_char b[], int i, int conv[])//����Ӧת��
{
	int index_bit_b = i;
	tuple_ index_u_char_b = bit2u_char(index_bit_b);
	int index_bit_a = conv[index_bit_b] - 1;
	tuple_ index_u_char_a = bit2u_char(index_bit_a);
	int temp = get_bit(a[index_u_char_a.u_char_], index_u_char_a.bit_);
	write(b[index_u_char_b.u_char_], index_u_char_b.bit_, temp);
}

//��ʼ�û�
void convertIP(u_char a[8], u_char b[8])//��a����IP�û����������b��
{
	for (int i = 0; i < 64; i++)
	{
		convert(a, b, i, IP);
	}
}

//���ʼ�û�
void convertIP_1(u_char a[8], u_char b[8])
{
	for (int i = 0; i < 64; i++)
	{
		convert(a, b, i, IP_1);
	}
}

//��Կ����
void Get_Keys(u_char key[8], u_char E_table[16][6])
{
	u_char keys[7] = {};
	for (int i = 0; i < 56; i++)
		convert(key, keys, i, PC_1);
	bitset<56> key_round[17];
	for (int i = 0; i < 16; i++)
		key_round[i].reset();
	for (int i = 0; i < 7; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			if (get_bit(keys[i], j) == 1)
				key_round[0].set(i * 8 + j);
		}
	}
	for (int i = 0; i < 16; i++)
	{
		bitset<56> left_mov = key_round[i] >> MOV[i];
		for (int j = 0; j < MOV[i]; j++)
		{
			left_mov.set(28 - MOV[i] + j, key_round[i][j]);
			left_mov.set(56 - MOV[i] + j, key_round[i][28 + j]);
		}
		key_round[i + 1] = left_mov;
	}

	//PC_2�û�
	for (int i = 0; i < 16; i++)
	{
		for (int j = 0; j < 48; j++)
		{
			write(E_table[i][j / 8], j % 8, key_round[i + 1][PC_2[j] - 1]);
		}
	}
}

//�ּ���
void Round(u_char m_[8], u_char E_table[16][6], u_char afterIP_1[8])
{

	u_char m[8] = {};
	convertIP(m_, m);

	u_char left[4], right[4];
	for (int i = 0; i < 4; i++)
	{
		left[i] = m[i];
		right[i] = m[i + 4];
	}
	for (int i = 0; i < 16; i++)
	{
		u_char afterE[6] = {};
		convertE(right, afterE);//E��չ�û�

		u_char afterXOR[6] = {};
		xor_(E_table[i], afterE, afterXOR);//����Կ��bit���

		u_char afterS[4] = {};
		convertS(afterXOR, afterS);

		u_char afterP[4] = {};
		convertP(afterS, afterP);

		u_char afterXOR2[4] = {};
		for (int i = 0; i < 4; i++)//��bit���
		{
			afterXOR2[i] = left[i] ^ afterP[i];
		}

		//������һ�ֵ�left��right
		for (int i = 0; i < 4; i++)
			left[i] = right[i];
		for (int i = 0; i < 4; i++)
			right[i] = afterXOR2[i];
	}

	//���ҽ���
	{
		u_char temp[4] = {};
		for (int i = 0; i < 4; i++)
		{
			temp[i] = left[i];
			left[i] = right[i];
			right[i] = temp[i];
		}
	}

	//�ϲ�
	u_char afterCombine[8];
	for (int i = 0; i < 4; i++)
	{
		afterCombine[i] = left[i];
		afterCombine[i + 4] = right[i];
	}

	//���ʼ�û�
	convertIP_1(afterCombine, afterIP_1);
}

//��չ�û�
void convertE(u_char a[4], u_char b[6])
{
	for (int i = 0; i < 48; i++)
	{
		convert(a, b, i, E);
	}
}

//48bit���
void xor_(u_char a[6], u_char b[6], u_char c[6])
{
	for (int i = 0; i < 6; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			int temp = get_bit(a[i], j) ^ get_bit(b[i], j);
			write(c[i], j, temp);
		}
	}
}

//S��
void convertS(u_char a[6], u_char b[4])
{
	bitset<48> a_;
	u_char b_[8];
	a_.reset();
	for (int i = 0; i < 48; i++)
	{
		a_.set(i, get_bit(a[i / 8], i % 8));
	}
	//S��
	for (int i = 0; i < 8; i++)
	{
		//��
		int box_index = a_[i * 6] * 2 + a_[i * 6 + 5];
		//��
		int line_index = 0;
		for (int j = 1; j <= 4; j++)
		{
			line_index = line_index * 2 + a_[i * 6 + j];
		}
		b_[i] = S[i][box_index * 16 + line_index];
	}
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			write(b[i], j, get_bit(b_[2 * i], 4 + j));
			write(b[i], j + 4, get_bit(b_[2 * i + 1], 4 + j));
		}
	}
	int i = 0;
}

//P�û�
void convertP(u_char a[4], u_char b[4])
{
	for (int i = 0; i < 32; i++)
		convert(a, b, i, P);
}

int test(u_char a[8], u_char b[8])
{
	int flag = 1;
	for (int i = 0; i < 8; i++)
	{
		if (a[i] != b[i])
		{
			flag = 0;
			break;
		}
	}
	return flag;
}

void funcEn(des_test_case m)//���ܹ���
{
	u_char key_final[16][6] = {};

	//cout << "key = " << endl;
	//for (int i = 0; i < 8; i++)
	//	cout << hex << (int)m.key[i] << " ";
	//cout << endl << endl;

	//������Կ
	Get_Keys(m.key, key_final);
	u_char cipher[8] = {};

	//cout << endl << "plaintext = " << endl;
	//for (int i = 0; i < 8; i++)
	//	cout << hex << (int)m.txt[i] << " ";
	//cout << endl;

	Round(m.txt, key_final, cipher);

	//cout << endl << "ciphertext = " << endl;
	//for (int i = 0; i < 8; i++)
	//	cout << hex << (int)cipher[i] << " ";
	//cout << endl;
	cout << test(m.out, cipher) << endl;
}

void funcDe(des_test_case c)
{
	//cout << endl << "ciphertext = " << endl;
	//for (int i = 0; i < 8; i++)
	//	cout << hex << (int)c.out[i] << " ";

	u_char key_final_[16][6] = {};
	u_char key_final[16][6] = {};
	Get_Keys(c.key, key_final_);
	for (int i = 0; i < 16; i++)
		for (int j = 0; j < 6; j++)
			key_final[15 - i][j] = key_final_[i][j];
	u_char m[8] = {};
	Round(c.out, key_final, m);

	//cout << endl << "plaintext = " << endl;
	//for (int i = 0; i < 8; i++)
	//	cout << hex << (int)m[i] << " ";
	//cout << endl;

	cout << test(c.txt, m) << endl;
}
